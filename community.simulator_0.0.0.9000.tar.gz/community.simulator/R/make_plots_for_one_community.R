#' Make graphs showing variance results from one case
#'
#' @param experiment_folder The folder where the experiment is stored
#' @param case_id_oi The case id of the case to be plotted
#'
#' @return List of graphs.
#' @export
#'
#' @examples NULL
make_plots_for_one_community <- function(experiment_folder,
                                         case_id_oi) {

  expt <- readRDS(paste0(experiment_folder, "experiment_table.RDS"))
  comm_measures <- readRDS(paste0(experiment_folder, "community_measures.RDS"))
  conn_temperatures <- DBI::dbConnect(RSQLite::SQLite(), paste0(experiment_folder, "temperatures.db"))
  temperatures <- dplyr::tbl(conn_temperatures, "temperatures")
  conn_dynamics <- DBI::dbConnect(RSQLite::SQLite(), paste0(experiment_folder, "dynamics.db"))
  dynamics <- dplyr::tbl(conn_dynamics, "dynamics")
  conn_temporal_derivs <- DBI::dbConnect(RSQLite::SQLite(),
                                         paste0(experiment_folder, "temporal_derivs.db"))
  temporal_derivs <- dplyr::tbl(conn_temporal_derivs, "derivs")
  conn_arbitrary_derivs <- DBI::dbConnect(RSQLite::SQLite(),
                                          paste0(experiment_folder, "arbitrary_derivs.db"))
  arbitrary_derivs <- dplyr::tbl(conn_arbitrary_derivs, "derivs")

  conn_delta_igr <- DBI::dbConnect(RSQLite::SQLite(), paste0(experiment_folder, "delta_igr.db"))
  delta_igr <- dplyr::tbl(conn_delta_igr, "delta_igr")

  comm_measures <- dplyr::full_join(comm_measures, expt)

  ## for testing
  # i <- 1
  # case_id_oi <- expt$case_id[i]
  env_series_oi <- expt |>
    dplyr::filter(case_id == case_id_oi) |>
    dplyr::pull(env_series_id)

  ## temperature time series
  temperatures_oi <- temperatures |>
    dplyr::filter(env_series_id == env_series_oi) |>
    dplyr::collect()
  p_tempseries <- temperatures_oi |>
    ggplot2::ggplot(ggplot2::aes(x = time, y = temperature)) +
    ggplot2::geom_line()

  p_temphist <- temperatures_oi |>
    ggplot2::ggplot(ggplot2::aes(x = temperature)) +
    ggplot2::geom_histogram(bins = 30)

  #p_tempseries / p_temphist


  ## data processing for species igr/deriv-temperature curves
  # comm_pars_i <- expt$community_object[expt$case_id==case_id_oi][[1]]
  # species_pars <- tibble(case_id = rep(case_id_oi, length(comm_pars_i$b_opt_i)),
  #                        species_id = paste0("Spp-", 1:length(comm_pars_i$b_opt_i)),
  #                        b_opt_i = comm_pars_i$b_opt_i,
  #                        a_b_i = comm_pars_i$a_b_i,
  #                        s_i = comm_pars_i$s_i,
  #                        a_d_i = comm_pars_i$a_d_i,
  #                        z_i = comm_pars_i$z_i)
  # species_pars1 <- species_pars %>%
  #   mutate(temperatures = list(temperatures_oi$temperature)) %>%
  #   unnest(cols = temperatures)
  # species_pars2 <- species_pars1 %>%
  #   mutate(igr = intrinsic_growth_rate2(a_b_i,
  #                                       b_opt_i,
  #                                       s_i,
  #                                       a_d_i,
  #                                       z_i,
  #                                       temperatures))
  # species_pars3 <- species_pars2 %>%
  #   nest_by(case_id, species_id) %>%
  #   mutate(models = list(mgcv::gam(igr ~ s(temperatures, k = 20),
  #                                  data = data))) %>%
  #   select(-data)
  # species_pars4 <- full_join(species_pars1, species_pars3) %>%
  #   group_by(case_id, species_id) %>%
  #   mutate(new_data = list(data.frame(temperatures = temperatures))) %>%
  #   select(-temperatures) %>%
  #   unique() %>%
  #   rowwise() %>%
  #   mutate(derivative = list(gratia::derivatives(models,
  #                                                data = new_data))) %>%
  #   unnest(derivative) %>%
  #   select(-models, -new_data) %>%
  #   rename(temperature = data) %>%
  #   mutate(igr = intrinsic_growth_rate2(a_b_i,
  #                                       b_opt_i,
  #                                       s_i,
  #                                       a_d_i,
  #                                       z_i,
  #                                       temperature)) %>%
  #   select(case_id, species_id, temperature, igr, derivative)

  species_pars4 <- arbitrary_derivs |>
    dplyr::filter(case_id == case_id_oi) |>
    dplyr::collect()

  #species_pars4 |>
  #  ggplot(aes(x = temperature, y = derivative, col = species_id)) +
  #  geom_point()

  ## species igr derivative-temperature curves
  p_igrtemp <- species_pars4 |>
    ggplot2::ggplot(ggplot2::aes(x = temperature, y = igr, col = species_id)) +
    ggplot2::geom_line()

  p_igrhist <- species_pars4 |>
    ggplot2::ggplot(ggplot2::aes(x = temperature, col = species_id)) +
    ggplot2::geom_histogram()

  p_igrderivtemp <- species_pars4 |>
    ggplot2::ggplot(ggplot2::aes(x = temperature, y = derivative, col = species_id)) +
    ggplot2::geom_line()

  #p_igrtemp / p_igrderivtemp

  ## diversity at temperature
  comm_div_temp <- species_pars4 |>
    dplyr::group_by(temperature) |>
    dplyr::summarise(mean_igrderiv = mean(derivative))

  p_comm_div_temp_mean <- comm_div_temp |>
    ggplot2::ggplot(ggplot2::aes(x = temperature, y = mean_igrderiv)) +
    ggplot2::geom_line()

  #p_igrtemp / p_igrderivtemp / p_comm_div_temp_mean

  ## community time series
  dynamics_oi <- dynamics |>
    dplyr::filter(case_id == case_id_oi) |>
    dplyr::collect()
  p_dynamics <- dynamics_oi |>
    ggplot2::ggplot(ggplot2::aes(x = time, y = log10(Abundance), col = Species_ID)) +
    ggplot2::geom_line()

  ## delta_igr time series
  delta_igr_oi <- delta_igr |>
    dplyr::filter(case_id == case_id_oi) |>
    dplyr::collect()
  p_delta_igr <- delta_igr_oi |>
    ggplot2::ggplot(ggplot2::aes(x = time, y = delta_igr, col = species_id)) +
    ggplot2::geom_line(linewidth = 0.1)


  p_delta_igr_sp1 <- delta_igr_oi |>
    dplyr::filter(species_id == "Spp-1") |>
    ggplot2::ggplot(ggplot2::aes(x = time, y = delta_igr, col = species_id)) +
    ggplot2::geom_line(linewidth = 0.1)

  #p_igrtemp / p_tempseries / p_delta_igr / p_dynamics

  graphs_list <- list(p_tempseries = p_tempseries,
                      p_temphist = p_temphist,
                      p_igrtemp = p_igrtemp,
                      p_igrhist = p_igrhist,
                      p_igrderivtemp = p_igrderivtemp,
                      p_comm_div_temp_mean = p_comm_div_temp_mean,
                      p_dynamics = p_dynamics,
                      p_delta_igr = p_delta_igr)

  return(graphs_list)
  #p_dynamics / p_tempseries / p_temphist

}
