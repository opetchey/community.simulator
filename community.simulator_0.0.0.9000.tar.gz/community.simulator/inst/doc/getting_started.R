## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(community.simulator)

## -----------------------------------------------------------------------------
project_folder_location <- tempdir()
experiment_name <- "getting_started_example"
experiment_design_filename <- "experiment_definition_template_v0.7.json"

setup <- setup_example_experiment(
  experiment_folder_location = project_folder_location,
  experiment_name = experiment_name,
  example_experiment_name = "test_experiment1",
  experiment_design_filename = experiment_design_filename,
  verbose = FALSE
)

## In a real project, this is the point where you would edit the JSON file
## inside `setup$experiment_folder` before running the workflow.

outputs <- suppressWarnings(
  suppressMessages(
    run_experiment(
      experiment_folder_location = project_folder_location,
      experiment_name = experiment_name,
      experiment_design_filename = experiment_design_filename,
      overwrite = TRUE,
      verbose = FALSE
    )
  )
)

outputs

## -----------------------------------------------------------------------------
community_measures <- readRDS(outputs$community_measures)

community_measures[, c("case_id", "richness", "temperature_mean", "CV_totab")]

