## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(community.simulator)


## ----c4-----------------------------------------------------------------------
species_and_community_properties <- read.csv("species_and_community_properties.csv")
species_and_community_properties |> 
  kableExtra::kbl() |> 
  kableExtra::kable_styling()

## -----------------------------------------------------------------------------
#  project_folder_location <- file.path("~/Desktop", "community_simulator_projects")
#  dir.create(project_folder_location, recursive = TRUE, showWarnings = FALSE)

## -----------------------------------------------------------------------------
#  project_folder_location <- file.path("~/Desktop", "community_simulator_projects")
#  experiment_name <- "test_experiment1"
#  experiment_design_filename <- "experiment_definition_template_v0.7.json"
#  
#  setup <- setup_example_experiment(
#    experiment_folder_location = project_folder_location,
#    experiment_name = experiment_name,
#    example_experiment_name = "test_experiment1",
#    experiment_design_filename = experiment_design_filename
#  )

## -----------------------------------------------------------------------------
#  outputs <- run_experiment(
#    experiment_folder_location = project_folder_location,
#    experiment_name = experiment_name,
#    experiment_design_filename = experiment_design_filename,
#    overwrite = FALSE
#  )

## -----------------------------------------------------------------------------
#  path_to_example_experiment_design_file <- system.file(file.path("test_experiments",
#                        "test_experiment1",
#                        "experiment_definition_template_v0.7.json"),
#              package = "community.simulator")
#  file_to_copy_to <- file.path("~/Desktop", "experiment_definition_template_v0.7.json")
#  file.copy(from = path_to_example_experiment_design_file, to = file_to_copy_to)
#  

## -----------------------------------------------------------------------------
eval(parse(text = "0"))

## -----------------------------------------------------------------------------
eval(parse(text = "c(0, 1, 2)"))

## -----------------------------------------------------------------------------
eval(parse(text = "0:10"))

## -----------------------------------------------------------------------------
eval(parse(text = "seq(0, 10, 2)"))

## ----eval = FALSE-------------------------------------------------------------
#  eval(parse(text = "word"))

## -----------------------------------------------------------------------------
eval(parse(text = "\"word\""))

## -----------------------------------------------------------------------------
eval(parse(text = "c(\"word1\", \"word2\")"))

